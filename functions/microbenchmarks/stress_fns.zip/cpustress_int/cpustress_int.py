import multiprocessing
import time
import sys
from python.src.utils.classes.commons.serwo_objects import SerWOObject
import random
def stresser():
    f = random.randint(0, 100000)
    while True:
        g = random.randint(0, 100000)
        h = random.randint(0, 100000)

        f = f * g + h
        
    return

def user_function(serwoObject) -> SerWOObject:
    try:
        cores_stress = 1
        time_stress = 10
        
        jobs = []
        for i in range(cores_stress):
            p = multiprocessing.Process(target=stresser)
            jobs.append(p)
            p.start()
        

        for j in range(time_stress):
            time.sleep(1)

        for j in range(len(jobs)):
            jobs[j].terminate()
        ret_val = {"data": "test"}
        return SerWOObject(body=ret_val)
    except Exception as e:
        print('in cpustress: ',e)
        return None
